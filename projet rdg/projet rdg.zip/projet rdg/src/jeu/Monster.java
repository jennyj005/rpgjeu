package jeu;

public class Monster extends Enemy
{

    Monster(String name, int hp, int degats)
    {
        super(name, hp, degats);
    }
}
