package jeu;

public abstract class Consumable extends Item
{
    public Consumable(String nomObjet)
    {
        super(nomObjet);
    }
}
