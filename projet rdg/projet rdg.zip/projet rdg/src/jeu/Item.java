package jeu;

public abstract class Item
{
    protected String nomObjet;

    public Item(String nomObjet)
    {
        this.nomObjet = nomObjet;
    }
}
